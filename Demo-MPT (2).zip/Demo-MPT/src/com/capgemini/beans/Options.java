package com.capgemini.beans;

public enum Options {
	
	byName, byId;

}
