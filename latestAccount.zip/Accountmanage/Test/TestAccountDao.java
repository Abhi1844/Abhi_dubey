import static org.junit.Assert.*;

import java.awt.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Account.Account;
import Dao.AccountDAoImp;
import Dao.AccountDao;

public class TestAccountDao {

	 private AccountDao daoref;
		@Before
		public void setup()
		{
			System.out.println("Setting Up DAO Object");
			daoref=new AccountDAoImp();
			System.out.println("-----------------------------------------------");
			System.out.println("-----------------------------------------------");
		}
		
		@Test
		public void test() {
			Account newA=new Account();
			newA.setId(15);
			newA.setBalance(2000);
			newA.setName("Abhinash");
			boolean flag=daoref.create(newA);
			assertTrue(flag);
			System.out.println("-----------------------------------------------");
			System.out.println("-----------------------------------------------");
			
		}
		@Test
		public void test2() {
			java.util.List<Account> ac1=daoref.findAll();
			boolean flag=ac1.isEmpty();
			assertFalse(flag);
			System.out.println("-----------------------------------------------");
			System.out.println("-----------------------------------------------");
		}
		@Test
		public void test3() {
			boolean flag=daoref.delete(3);
			assertTrue(flag);
			System.out.println("-----------------------------------------------");
			System.out.println("-----------------------------------------------");
		}
		@Test
		public void test4() {
			boolean flag=false;
			Account ac1=daoref.findById(1);
			if(ac1==null)
			{
				flag=false;
			}
			else
			{
				flag=true;
			}
			assertTrue(flag);
			System.out.println("-----------------------------------------------");
			System.out.println("-----------------------------------------------");
		}
		@Test
		public void test5() {
			Account unewA=new Account();
			unewA.setId(15);
			unewA.setBalance(2000);
			unewA.setName("Abhinash");
			boolean flag=daoref.update(2,unewA);
			assertTrue(flag);
			System.out.println("-----------------------------------------------");
			System.out.println("-----------------------------------------------");
			
		}
		
		@After
		public void teardown()
		{
			System.out.println("Cleaning Up DAO Object");
			daoref=null;
		}
}
