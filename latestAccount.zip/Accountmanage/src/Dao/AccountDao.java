package Dao;

import java.util.List;

import Account.Account;
import Account.Option;

public interface AccountDao {
	public List<Account> findAll();
	public List<Account> sortAccountDetails(Option option);
	public boolean create(Account account);
	public boolean delete(int id);
	public boolean update(int id,Account account);
	public Account findById(int id);
}
