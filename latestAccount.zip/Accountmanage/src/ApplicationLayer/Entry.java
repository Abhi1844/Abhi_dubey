package ApplicationLayer;

import java.util.List;

import Account.Account;
import Account.Option;
import ServiceLayer.AccountServiceImp;
import ServiceLayer.Accountservice;

public class Entry {
public static void main(String[] args) {
	Accountservice service=new AccountServiceImp();
	
	Account newAccount= new Account();
	newAccount.setId(8);
	newAccount.setBalance(8000);
	newAccount.setName("Rakesh");
	boolean flag=service.create(newAccount);
	System.out.println("New Account Created? "+flag); 
	List<Account> account=service.findAll();
	for(Account account1:account)
	{
		System.out.println(account1);
	}
	System.out.println("------------------------------------------------------------------");
	account=service.sortAccountDetails(Option.byName);
			for(Account account1:account)
			{
				System.out.println(account1);
			}
			System.out.println("------------------------------------------------------------------");
	account=service.sortAccountDetails(Option.byId);
			for(Account account1:account)
			{
				System.out.println(account1);
			}
			boolean flag1=service.delete(1);
			System.out.println("------------------------------------------------------------------");
			System.out.println("------------------------------------------------------------------");
			Account updateAccount= new Account();
			updateAccount.setId(2);
			updateAccount.setBalance(8000);
			updateAccount.setName("Rishi");
			boolean flag2=service.update(2,updateAccount);
			account =service.findAll();
			System.out.println(flag2);
			for(Account account1:account)
			{
				System.out.println(account1);
			}
			System.out.println("Account details by this id are: \n"+service.findById(3));
			
			System.out.println("-------------------------------------");
			
}
}
