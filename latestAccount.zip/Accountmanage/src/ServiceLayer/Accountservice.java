package ServiceLayer;

import java.util.List;

import Account.Account;
import Account.Option;

public interface Accountservice {
public List<Account> findAll();
public List<Account> sortAccountDetails(Option option);
public boolean create(Account account);
public boolean delete(int id);
public boolean update(int id,Account account);
public Account findById(int id);
}
