package ServiceLayer;


import java.util.List;

import Account.Account;
import Account.Option;
import Dao.AccountDAoImp;
import Dao.AccountDao;

public class AccountServiceImp implements Accountservice {
private AccountDao daoref =new AccountDAoImp();

@Override
public List<Account> findAll() {
	// TODO Auto-generated method stub
	List<Account> account=daoref.findAll();
	return account;
}

@Override
public List<Account> sortAccountDetails(Option option) {
	// TODO Auto-generated method stub
	List<Account> account=daoref.sortAccountDetails(option);
	return account;
}

@Override
public boolean create(Account account) {
	// TODO Auto-generated method stub
	return daoref.create(account);
}

@Override
public boolean delete(int id) {
	// TODO Auto-generated method stub
	return daoref.delete(id);
}

@Override
public boolean update(int id, Account account) {
	// TODO Auto-generated method stub
	return daoref.update(id,account);
}

@Override
public Account findById(int id) {
	// TODO Auto-generated method stub
	return daoref.findById(id);
}  
}
