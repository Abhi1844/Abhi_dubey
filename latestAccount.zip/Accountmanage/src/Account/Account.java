package Account;

public class Account {
	private int id;
	private double balance;
   private String name;
public Account() {
	super();
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Name Is::"+name+"\n"+"Balance is::"+balance+"\n"+"Id is::"+id;
}
}
