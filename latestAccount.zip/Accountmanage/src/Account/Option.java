package Account;

public enum Option {
   byName,byId;
}
