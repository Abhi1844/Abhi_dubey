import java.util.*;

public class Bank 
{

	int id;
	static double total = 0;
	Account[] account=new Account[5];

	public Bank() 
	{
		account[0] = new Account(1, 1000.0);
		account[1] = new Account(2, 500.0);
		account[2] = new Account(3, 200.0);
		account[3] = new Account(4, 1500.0);
		account[4] = new Account(5, 2000.0);

	}

	public void transferAmount(int toAccount, int fromAccount, double amount) 
	{
		for (int i = 0; i < 5; i++) 
		{
			if (account[i].getId() == toAccount) 
			{
				account[i].deposit(amount);
			}
			if (account[i].getId() == fromAccount) 
			{
				account[i].withdraw(amount);
			}
		}
	}

	public void showTotalBalance()
	{
		System.out.println("1."+account[0].getBalance());
		System.out.println("2."+account[1].getBalance());
		System.out.println("3."+account[2].getBalance());
		System.out.println("4."+account[3].getBalance());
		System.out.println("5."+account[4].getBalance());
		
		for(int i = 0;i<5;i++)
		{
		total = total + account[i].getBalance();
		}
		System.out.println("total balance is: "+total);
	}
}