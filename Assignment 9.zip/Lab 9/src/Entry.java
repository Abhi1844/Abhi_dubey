import java.util.Scanner;

public class Entry {

	public static void main(String args[])
	{
		Teller t = new Teller();
		t.performTransfer();
	}

}
