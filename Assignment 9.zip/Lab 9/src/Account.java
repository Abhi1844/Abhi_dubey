
public class Account {
	
	int id;
	double balance;
	Account[] account;
	
	public Account(int id, double balance)
	{
		this.id = id;
		this.balance=balance;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Account[] getAccount() {
		return account;
	}

	public void setAccount(Account[] account) {
		this.account = account;
	}

	public boolean deposit(double amount)
	{
		this.balance=this.balance+amount;
		return true;
	}
	
	public boolean withdraw(double amount)
	{
		this.balance=this.balance-amount;
		return true;
	}
}
