
public class Teller {
	
	public Teller()
	{
	
	}
	
	Bank bk = new Bank();
	
	public void performTransfer()
	{
		bk.transferAmount(1,2,100.0);
		bk.transferAmount(3,4,10.0);
		bk.transferAmount(1, 5, 120);
		bk.transferAmount(1, 4, 600);
		bk.showTotalBalance();
		
	}
	
}
